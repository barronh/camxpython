"""
Preparing Python Environment
============================

The basic steps are:

1. Create a requirements file.
2. Install a new virtual environment (pycx).

    - Load the virtual environment.
    - Install libraries.
    - Unload the virtual environment.

3. Reload


Make requirements.txt
'''''''''''''''''''''

Below is a bash command that makes a requirements.txt

.. code-block:: bash

    cat << EOF > requirements.txt
    netCDF4>=1.5.8,!=1.7.0,!=1.7.1
    pseudonetcdf>=3.5
    numpy>=1.19.5,<2
    scipy>=1.5.4
    pandas>=1.1.5
    xarray>=0.16.2
    pyproj>=2.6.1
    pycno
    pyrsig>=0.12.0
    cmaqsatproc>=0.5.2
    EOF

Install a new virtual environment
'''''''''''''''''''''''''''''''''

- Make a new virtual environment (pycx)
- Load the virtual environment.
- Install libraries.
- Unload virtual environment (optional)

.. code-block:: bash

    python3 -m venv pycx
    source pycx/bin/activate
    python -m pip install -r requirements.txt
    deactivate

Reload Environemnt
''''''''''''''''''

Any time you want to use the python environment, load it.

.. code-block:: bash

    source pycx/bin/activate

The environment will stay active until you either run deactivate or logout.
"""
